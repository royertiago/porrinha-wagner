#include <iostream>

#include <string>
#include "Factory.h"
#include "TipoJogador.h"
#include "Jogo.h"
using namespace std;

int main(int argc, char *argv[]=0)
{
    vector<TipoJogador*> jogadores=Factory::criarJogadores();
    int jogos=5;

    if(argc>1){
        string temp=argv[0];
        std::cout<< temp <<std::endl;
       // jogos=std::stoi (temp);
    }
    Jogo jogo= Jogo(jogadores);

    jogo.comecar();




    return 0;
}
