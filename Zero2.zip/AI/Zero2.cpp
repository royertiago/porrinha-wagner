#include "Zero2.h"
#include "util.h"
namespace zero2 {
	Zero2::Zero2(std::string name):_name(name)
	{

	}

	Zero2::~Zero2()
	{

    }
	int Zero2::hand() {
		return 0;
	}
	int Zero2::guess ( const std::vector<int>& cantadas ) {
	    return core::chopstick_count()/2;


	}
	void Zero2::settle_round(
                const std::vector<int>& hands,
                const std::vector<int>& guesses
    ) {}
    std::string Zero2::name() const{

    }

}

