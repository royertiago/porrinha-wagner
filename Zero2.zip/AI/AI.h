class Player;
namespace zero2 {
    Player * generate( int players, int chopsticks );
} // namespace human_player
