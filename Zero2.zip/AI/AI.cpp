#include "ai.h"
#include "Zero2.h"
namespace zero2 {
    Player * generate( int players, int chopsticks ){
        return new Zero2();
    }
} // namespace human_player
